# Safex – Suggested Mobile UI (v11)

Mobile-first Safex UI mockup. The v11 update adds an **Install App** entry and app-wide appearance controls in the More section.

## More menu

- **Install Safex App** — add Safex to the device Home Screen when the browser supports PWA installation.
- **Appearance** — open theme and colour settings. Existing items such as Library, Circulars & Notices, Reward Wall and staff login remain available. Dashboard is not shown on Home.

## Appearance settings

- Display mode: **System**, **Light**, or **Dark**.
- Colour themes: **Safex** (navy/amber), **Ocean**, **Forest**, and **High contrast**.
- Apply the preference across the header, Home, report forms, cards, navigation tabs and controls; save it on the device.
- Keep SOS red and status colours consistent with their safety meanings.

## Install App behaviour

- Add a visible **Install Safex App** button under More.
- On a supported PWA browser, the button should invoke the browser install prompt. The user may still need to approve the OS/browser confirmation.
- If no install prompt is available, show platform guidance such as browser menu → Install app/Add to Home Screen; on iPhone, Share → Add to Home Screen.
- This is a PWA installation, not a silent APK download. Production requires HTTPS, a valid web app manifest and a service worker; exact prompt availability depends on browser/device.

## Existing app/site rules retained

- Multi-site vendor: choose the current site at app open; Home, My Site Reports and SOS follow it. Header shows selected site and Change Site. Single-site vendor: skip the picker and open that site’s Home directly.
- My Site Reports follows the selected site without an Employee No. lookup. All Site Reports continues to require Employee ID + registered mobile + OTP.
- SOS uses the selected site’s admin-configured emergency contact.
- Six languages, voice reporting, site report summaries, notification preferences and privacy safeguards remain in the mockup.

## Prototype limitation

The HTML/Markdown are visual prototypes, not connected to the production Safex app, PWA install events, user preferences, push service, Supabase or real SOS numbers. The More settings shown here need production integration to persist/apply themes and trigger installation.
