# Safex – Suggested Mobile UI (v3)

6 languages and voice reporting

E

**EMVEESS**Tata Steel vendor

SOS

Englishहिन्दीଓଡ଼ିଆবাংলাਪੰਜਾਬੀमराठी

कर्मचारी कोड डालें**खोजें**

**184**दिन बिना दुर्घटना

## रिपोर्ट करें

**नियर मिस**\
बाल-बाल बचे

**खतरा**\
Hazard बताएं

**निरीक्षण**\
UC / UA

**फीडबैक**\
अनुभव बताएं

**शिकायत / खुलकर बोलें**\
गुमनाम भी

**सुझाव**\
आइडिया दें

## देखें और सीखें

मेरी रिपोर्ट

ट्रेनिंग

डैशबोर्ड

लाइब्रेरी

सर्कुलर

रिवॉर्ड वॉल

होम

सेफ्टी अलर्ट

रिपोर्ट

ट्रेनिंग

और

1\. Home: 6 languages on front page

← नियर मिस रिपोर्ट

Englishहिन्दीଓଡ଼ିଆবাংলাਪੰਜਾਬੀमराठी

**गुमनाम रूप से भेजें**\
नाम और ID नहीं दिखेगा

कर्मचारी ID

EMV-10482

जगह

साइट-4, ब्लास्ट फर्नेस ▾

कितना गंभीर हो सकता था?

कम

मध्यम

ज़्यादा

क्या हुआ?

लिखें या माइक दबाकर बोलें

तुरंत क्या कार्रवाई की? (वैकल्पिक)

लिखें या बोलें

रिपोर्ट भेजें

2\. Form: language bar + mic on each text field

← बोलकर बताएं

सुन रहा है… 0:12 · हिन्दी

कल शाम गेट नंबर 4 के पास क्रेन से सामान गिरते-गिरते बचा, नीचे दो लोग काम कर रहे थे।

आप टेक्स्ट ठीक कर सकते हैं। आपकी आवाज़ भी रिपोर्ट के साथ सेव होगी।

फिर से

रोकें

ठीक है, भेजें

3\. Voice recording

E

**EMVEESS**Tata Steel vendor

SOS

Englishहिन्दीଓଡ଼ିଆবাংলাਪੰਜਾਬੀमराठी

कर्मचारी कोड डालें**खोजें**

होम

सेफ्टी अलर्ट

रिपोर्ट

ट्रेनिंग

और

## क्या रिपोर्ट करना है?

**नियर मिस**

**खतरा (Hazard)**

**निरीक्षण (UC / UA)**

**फीडबैक**

**शिकायत**

**खुलकर बोलें (गुमनाम)**

**सुझाव**

4\. Centre Report button sheet

- **6 languages:** English, हिन्दी, ଓଡ଼ିଆ, বাংলা, ਪੰਜਾਬੀ, मराठी. The strip is on the front page and on every form. The choice is remembered on the phone.
- **Mic on all 7 report types:** Near miss, Hazard, UC/UA, Feedback, Grievance, Speak up, Suggestion. Employee speaks in their language, checks the text, then submits.
- **Speak up stays anonymous** when the toggle is on. The voice note is saved without name or ID.
- **Odia caveat:** browser voice typing works well for Hindi, English, Bengali, Punjabi and Marathi, but is weak for Odia. For Odia, a cloud speech service or saving the voice note as audio is the safer option.