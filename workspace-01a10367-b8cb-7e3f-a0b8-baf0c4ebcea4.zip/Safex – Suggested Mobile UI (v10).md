# Safex – Suggested Mobile UI (v10)

Mobile-first Safex UI mockup with six languages, voice reporting, site-aware content, report views, push notification preferences, and location-specific SOS.

## Site selection and page loading

### Multi-site vendor

- On each fresh website/app visit, ask: **“Aap abhi kis site par kaam kar rahe hain?”**
- Show a dropdown populated from that vendor’s configured sites, for example: Jamshedpur, Kalinganagar, Ludhiana.
- After the user chooses a site, load that site’s home page, Safety Alerts, circulars and report feed.
- Display the selected site in the header, e.g. **Kalinganagar · Change site**. Choosing **Change site** opens the site selector again and refreshes the site-scoped content.
- The SOS button uses the selected site’s emergency contact. Show the site/contact before calling; if the user is at another site, they can change site in the header.

### Single-site vendor

- Resolve the vendor from its URL/custom domain.
- If the vendor has only one configured site, select it automatically and skip the location prompt. Show the site name in the header.

## View Reports

The “My Site Reports” view uses the active site selected at app open; **no Employee No. filter is needed**. It displays that site’s Near Miss, Hazard and Unsafe Condition (UC) summaries, with type filters and status counts.

Each worker-facing summary includes report ID, type, masked reporter ID, site name, area/location, short description, date and current status. Opening a report shows its details, status history and a privacy-reviewed attachment preview when available. Full reporter IDs and original, unredacted attachments are reserved for authorized staff.

**All Site Reports** remains a separate option: enter Employee ID and the mobile number on the employee record, verify the OTP sent to that registered number, then view redacted summaries across sites within that employee’s vendor tenant. It never opens another vendor’s data.

## Header notifications

- A bell beside SOS opens push-notification preferences.
- Users can enable/disable push on the device and choose categories: published Safety Alerts/notices, circulars/events/training, rewards, their own report-status changes, and optional updates across their vendor’s sites.
- Hide report details on the phone lock screen by default. Notify on relevant publications and the employee’s own report-status changes—not every click, draft or internal edit.
- Production push requires browser/OS permission, a service worker, a push subscription and a server-side push sender. The mockup controls are visual only.

## Site-specific SOS

- Each site has its own emergency number, configured by that site’s Admin.
- SOS uses the current selected site, displays the selected site and number, and then offers the call action. The header’s Change Site option changes which site-specific SOS contact is used.
- If a site number is missing, show an Admin-configured backup contact rather than a dead or incorrect call action.
- No real phone numbers were provided, so the HTML uses placeholders.

## Other UI included

- Languages: English, Hindi, Odia, Bengali, Punjabi and Marathi.
- Report types: Near Miss, Hazard, UC/UA, Feedback, Grievance, Speak Up and Suggestion.
- Voice input/mic affordance on report fields; anonymous Speak Up stays unlinked to an Employee No.
- Report form supports an attachment/photo and a current status in the report detail view.

## Backend/security implementation notes

- Resolve the tenant from the validated domain and verify the selected site belongs to that tenant. Enforce `tenant_id` and `site_id` on the backend/RLS; do not rely on a site ID supplied by the browser or stored in `localStorage` as authorization.
- Site selection is a page/report filter, **not identity verification**. All Site Reports still requires the registered-mobile OTP flow.
- Keep worker-facing cross-site/site summaries redacted. Mask reporter Employee IDs and review/redact image previews; keep full IDs and original files access-controlled.
- This is a static HTML/Markdown mockup. It is not connected to Safex, Supabase, a push service or real SOS contacts, and it does not enforce access control.


## v8 change

- Removed the Dashboard shortcut from the Home “देखें और सीखें” quick-access grid. The grid now contains View Reports, Training, Library, Circulars and Reward Wall.


## v9 — Single-site companies open Home directly

- If the vendor has exactly **one active site**, opening its website/app loads the Home page for that site immediately.
- Do **not** show the site-selection prompt, dropdown or Change Site control for a single-site vendor. The site name can remain visible in the header, and SOS uses that site's configured contact.
- For a multi-site vendor, keep the opening site picker; after selection, load the chosen site's Home and show the selected site plus Change Site in the header.
- Resolve the vendor/site count from the validated vendor domain and server configuration. If one active site exists, set it as the site context automatically; if multiple exist, require the picker.


## v10 — Employee ID/name autocomplete in reporting

- In the report form, search by either **Employee No. or employee name**.
- Show matching suggestions as the user types, with **name + Employee No. + designation** so the right person can be selected.
- Once selected, auto-fill Employee No., name and designation from the employee master; keep these fields read-only in the form.
- The visual prototype has a small **demo-only** sample master and a working client-side autocomplete to show the interaction. It does not connect to the real employee master.
- Production lookup should be server-side, scoped to active employees in the currently selected vendor/site, rate-limited, and return only the minimum required fields. Do not expose/download the entire master sheet.
- When anonymous reporting is enabled, clear and hide employee identity fields so the report is not associated with that employee.
