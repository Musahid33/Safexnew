# Safex – Suggested Mobile UI (v4)

6 languages and voice reporting

E

**EMVEESS**Tata Steel vendor

SOS

Englishहिन्दीଓଡ଼ିଆবাংলাਪੰਜਾਬੀमराठी

कर्मचारी कोड डालें**खोजें**

**184**दिन बिना दुर्घटना

## रिपोर्ट करें

**नियर मिस**\
बाल-बाल बचे

**खतरा**\
Hazard बताएं

**निरीक्षण**\
UC / UA

**फीडबैक**\
अनुभव बताएं

**शिकायत / खुलकर बोलें**\
गुमनाम भी

**सुझाव**\
आइडिया दें

## देखें और सीखें

रिपोर्ट देखें

ट्रेनिंग

डैशबोर्ड

लाइब्रेरी

सर्कुलर

रिवॉर्ड वॉल

होम

सेफ्टी अलर्ट

रिपोर्ट

ट्रेनिंग

और

1\. Home: 6 languages on front page

← नियर मिस रिपोर्ट

Englishहिन्दीଓଡ଼ିଆবাংলাਪੰਜਾਬੀमराठी

**गुमनाम रूप से भेजें**\
नाम और ID नहीं दिखेगा

कर्मचारी ID

EMV-10482

जगह

साइट-4, ब्लास्ट फर्नेस ▾

कितना गंभीर हो सकता था?

कम

मध्यम

ज़्यादा

क्या हुआ?

लिखें या माइक दबाकर बोलें

तुरंत क्या कार्रवाई की? (वैकल्पिक)

लिखें या बोलें

रिपोर्ट भेजें

2\. Form: language bar + mic on each text field

← बोलकर बताएं

सुन रहा है… 0:12 · हिन्दी

कल शाम गेट नंबर 4 के पास क्रेन से सामान गिरते-गिरते बचा, नीचे दो लोग काम कर रहे थे।

आप टेक्स्ट ठीक कर सकते हैं। आपकी आवाज़ भी रिपोर्ट के साथ सेव होगी।

फिर से

रोकें

ठीक है, भेजें

3\. Voice recording

E

**EMVEESS**Tata Steel vendor

SOS

Englishहिन्दीଓଡ଼ିଆবাংলাਪੰਜਾਬੀमराठी

कर्मचारी कोड डालें**खोजें**

होम

सेफ्टी अलर्ट

रिपोर्ट

ट्रेनिंग

और

## क्या रिपोर्ट करना है?

**नियर मिस**

**खतरा (Hazard)**

**निरीक्षण (UC / UA)**

**फीडबैक**

**शिकायत**

**खुलकर बोलें (गुमनाम)**

**सुझाव**

4\. Centre Report button sheet

- **6 languages:** English, हिन्दी, ଓଡ଼ିଆ, বাংলা, ਪੰਜਾਬੀ, मराठी. The strip is on the front page and on every form. The choice is remembered on the phone.
- **Mic on all 7 report types:** Near miss, Hazard, UC/UA, Feedback, Grievance, Speak up, Suggestion. Employee speaks in their language, checks the text, then submits.
- **Speak up stays anonymous** when the toggle is on. The voice note is saved without name or ID.
- **Odia caveat:** browser voice typing works well for Hindi, English, Bengali, Punjabi and Marathi, but is weak for Odia. For Odia, a cloud speech service or saving the voice note as audio is the safer option.

## v4 update — View Reports (site-scoped)

The home quick-access item is now **रिपोर्ट देखें / View Reports**. The new flow has three screens:

1. **Choose report scope**
   - **All Site Reports:** all sites under the same vendor; Safety Officer/Vendor Admin staff login and permission required.
   - **My Site Reports:** enter an Employee No. to look up which site it belongs to. The Employee No. is only a site filter—not login or identity verification. The example `EMV-10482` resolves to `Kalinganagar`.
2. **My Site report list**
   - Site-level totals and filters for Near Miss, Hazard and Unsafe Condition (UC).
   - Each summary shows report ID, type, masked “Reported by” Employee No., area/location, site name, short description, reported date and current status.
3. **Report detail**
   - Shows the same report fields plus the longer description, current status/history and a reviewed attachment-photo preview when one was uploaded.

### Data and access rules

- Resolve Employee No. against the employee master on the server, then filter reports by the resolved `tenant_id` and `site_id`. Do not accept a browser-supplied site ID or use `localStorage` as authorization.
- Because Employee No. is only a lookup, anyone who knows/guesses a number could select that employee’s site. Therefore, the worker-facing list must contain only approved, site-safe summaries; mask reporter IDs and review/redact photos before showing previews. Keep full reporter IDs and original unredacted attachments for authorized staff.
- Ordinary employees see their resolved site only. Cross-site raw reports are for authorized staff within the same vendor tenant; employees can instead receive approved, de-identified Safety Alerts/Lessons Learned.
- Anonymous reports remain unlinked to an Employee No. and display as **Anonymous**.
- This is a **static UI prototype**. The attached HTML/Markdown do not connect to Supabase or enforce access control. Backend filtering and RLS still need to be implemented and tested in the actual app.
