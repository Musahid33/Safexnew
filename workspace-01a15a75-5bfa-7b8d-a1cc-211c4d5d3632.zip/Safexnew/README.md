# Safex production starter

A Next.js + TypeScript PWA-oriented Safex app. The SafexNew Supabase schema and the initial West Bokaro employee master are now provisioned. The public site still needs the Vercel server-only employee-directory configuration before live lookup works; reports, OTP/SMS, VAPID, SOS and other operational workflows remain demo/disabled until configured.

## Included now

- Responsive safety home inspired by the latest mobile reference: compact tenant/site header, six-language chip strip, stacked report/training/circular shortcuts, a Document Vault / Library grid for SOP/SWP, Risk Assessments, Legal & Statutory Compliance, Policy & Procedures and MoM, a Wall of Fame / Reward Wall carousel with a stationary Name / Reward For table beneath the images, plus the nearest upcoming event in Explore & Learn. Circular and notice archives remain accessible without latest-item cards on Home. The Report chooser retains all nine types: Near Miss, UC, UA, Hazard, Grievance, Speak Up, Suggestion, Feedback and Safety Observation.
- Multi-site first-open selector; session site context; Change Site in the header. Single-site tenant logic is represented in code (one site auto-selects).
- Site-filtered My Site Reports (no Employee No. filter) and an All Site Reports OTP entry screen.
- Reference-inspired reporting flows: direct UC (Unsafe Condition) and UA (Unsafe Act) forms, plus Safety Observation safe-practice options; Hazard accident/property-damage/red-risk choices; Feedback, Grievance and Suggestion category pickers; tailored fields for Near Miss, Hazard, observations, Speak Up and other concerns.
- Report form fields include worker lookup, name/Employee ID/designation autofill, location, department where relevant, incident date/time, severity where relevant, description, immediate action and optional image (12 MB limit). Anonymous reporting is available only for Speak Up; that mode hides identity and stores no employee link. Other report types require a selected employee profile.
- The **employee master uses real records only**. The initial 193-row WBD roster is imported into the tenant/site-scoped Supabase tables; do not commit or publish a roster export. Configure the server-only `SUPABASE_SERVICE_ROLE_KEY`, `SAFEX_EMPLOYEE_DIRECTORY_SOURCE=auto`, and `SAFEX_TENANT_SLUG=emveess-infraventures` in the production environment. The public lookup returns only Employee ID, name and designation for an exact active match at the selected site. Unavailable sources return HTTP 503; there is no synthetic fallback. See `docs/employee-master.md`.
- Site-scoped Employee ID search under **More → Search Employee Profile** opens a responsive Employee Passport directly after a match. The passport includes a download-icon PNG export, QR to open Safex, privacy-marked personal detail cards, six clickable KPI panels and searchable/filterable record modals. Public lookup only returns ID, name and designation: other personal fields, photograph, performance counts and history are explicitly unavailable rather than invented. Passport download is a directory-only preview, not proof of identity or safety clearance. Real history/PII requires a verified employee session, consent and a protected backend before enabling it.
- Demo Employee Code profile search, an account login screen for Employees, Safety Supervisors/Site Supervisors and Admins (Employee ID + registered-mobile OTP preview; staff password login/reset previews), and a Training Management portal with a site-scoped Employee Code training check.
- The Admin / HSE Manager dashboard is the uploaded `SafetyOS — Employee Profile Preview (2).html` console, mounted as designed rather than re-implemented: all 18 screens (Case Management, Training Management, Employee Profile, Communications, Document Vault / Library, Audit & Inspection, Form Builder, DM, User & Access, Dashboard, View & Analytics, Certificates, Export Reports, Direct Data Entry, Daily Management, System Settings) with their charts, tables, form builder, CSV / report export and in-memory demo records. Reach it from the Admin login tab; access to the roster requires the server-verified operator session below. The design is the source of truth: edit the HTML and run `npm run design:extract` to regenerate `app/safetyos.css` and the two modules in `app/components/safetyos/generated/` (markup + script); never hand-edit those. Admin login is now a real frontend-to-backend call: the dialog (and, after the session cookie expires, the console's own sign-in gate) POSTs its credentials to `/api/admin/session`, which verifies them server-side in constant time — either the operator passcode from `SAFEX_ADMIN_PASSCODE` or the dummy demo username/password in `lib/admin-credentials.ts` — and answers with the HMAC-signed session cookie. The console then feeds the real employee master into the design's own directory through the seam in `scripts/extract-design.mjs`; that seam maps only employee number, name, designation and department, so mobile numbers, blood groups and safety pass numbers are never handed to the console even when the API is allowed to release them. When the employee-master source is not configured or reachable, the console opens with an empty directory and a status banner instead of a wall — no synthetic employees are invented. Demo login itself still does not verify a real staff role or authenticate with Supabase, and the embedded console’s edits stay in browser memory. The separate protected reward editor described below does write to Supabase.
- Site-scoped report outbox for offline use: each report and its optional image are saved in IndexedDB first, then retried on reconnect/focus and with Background Sync where supported. A server-side Supabase endpoint uses a stable submission ID for idempotent retries, validates tenant/site/employee scope, enforces a database-backed request limit, and stores optional evidence in a private bucket. This stays disabled until the server configuration and offline-sync migration are applied.
- Site-specific SOS screen; emergency contacts are intentionally `null` until you supply verified numbers.
- Safety Portal hero with a Life Saving Rule location picker and popup; actual company-approved, location-specific rules must be supplied before operational use.
- Notification preference UI, browser permission request and service-worker push display/click handlers.
- More → Appearance (System/Light/Dark and four palettes) and More → Install App.
- Six language labels for key navigation/form actions. Longer translations require review by native speakers.
- Supabase client wrappers, environment template, the existing Safex tenant/site migrations, and an additive schema extension for the live multi-tenant database.
- Demo tenant company branding in the header and per-tenant optional-module flags; the footer is intentionally removed, and the shared core UI remains consistent across companies.

## Run locally

```bash
npm install
npm run dev
```

Open the local preview. Copy `.env.example` to `.env.local` and configure the public URL/key plus server-only secrets as described below. `/api/health` checks Supabase Auth reachability. The SafexNew project has the additive tenant/site schema and the WBD employee master, but `/api/bootstrap` will still report `directory: unavailable` until the deployment has `SUPABASE_SERVICE_ROLE_KEY`, `SAFEX_EMPLOYEE_DIRECTORY_SOURCE=auto`, and the correct `SAFEX_TENANT_SLUG`. Report sync remains disabled and demo reports are **not sent to Supabase**. The uploaded `officer-dashboard.html` was used as a static UI/feature reference only; its embedded Supabase project differs from this app's configured project and its direct browser-table writes were not imported.

## Deploy on Antideploy

- The production start command runs Next.js on `0.0.0.0` and uses the platform-provided `PORT`; local development remains on port 3000.
- Antideploy account authorization is stored outside this project in `~/.antideploy/config.json` with mode `0600`. The project’s `.antideploy.json` will contain only the selected application ID, not an account token.
- The local preview has the public Supabase endpoint configured; Antideploy will need the same public URL/key set in its environment. Public configuration alone does not connect the schema, employee directory or report persistence. Keep report sync disabled until migrations/data are applied and required server-only secrets and tenant controls are configured.
- Never include account tokens, service-role keys, or the OpenRouter key previously posted in project files or deploy archives.

## Configure Supabase safely

1. Create a Supabase project and copy `.env.example` to `.env.local`.
2. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` (legacy `NEXT_PUBLIC_SUPABASE_ANON_KEY` is also accepted).
3. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only in the deployment platform's encrypted environment (for example Vercel or Antideploy). Never commit it, put it in `.env.local` shared with others, send it in chat, expose it to the browser, or prefix it with `NEXT_PUBLIC_`.
4. SafexNew's live migration history includes the original four migrations plus `supabase/migrations/20261020171922_safex_existing_schema_extension.sql`. That extension is additive and expects the existing `tenants`/`sites`/employee/report schema; do not apply it as a standalone greenfield migration. Review the entire history before using it on a different project.
   Then apply `supabase/sql/02_rls.sql` — a re-runnable grants/RLS/policy hardening script split into independently runnable PARTs, with an apply ledger so a run that times out in the SQL editor can be resumed. Finish with `supabase/sql/99_gate_test.sql`, which must report PASS on every row (it raises an exception otherwise, so it can gate a deploy).
5. Map and verify vendor domains, sites, roles and actual report columns. Test RLS as anonymous, employee, site officer, vendor admin and a different tenant before production.

The migration deliberately denies direct anonymous access to employee/report tables. This repo's narrow employee lookup is implemented as a server route, but its Vercel server-only Supabase configuration still needs to be set and verified. Anonymous report submission, OTP-protected cross-site summaries and attachment previews still need their production endpoint/authentication workflows. Do not grant public SELECT on raw reports or rely on a browser `site_id`/localStorage value.

## Rewards & Recognition (backend)

- Apply `supabase/migrations/202610100004_recognitions.sql` after the initial schema. Set server-only `SUPABASE_SERVICE_ROLE_KEY` and `SAFEX_TENANT_SLUG` to the tenant whose rewards this deployment will display (the provisioned SafexNew tenant slug is `emveess-infraventures`). Do not set the service key in the browser.
- Set a strong server-only `SAFEX_ADMIN_PASSCODE` (12+ characters). Sign in at `/admin/recognitions` (or use **Manage rewards** from the unlocked SafetyOS console). Add **Name** and **Reward For**, optionally an image in `public/rewards/` (entered as `/rewards/photo.jpg`) or a public image URL from your configured Supabase Storage project; tick the consent confirmation and then **Publish**. Edit, unpublish or delete from the same screen. Only this server-verified operator session may write. The existing in-console “Reward Entry” preview is still demo-only and does **not** save.
- `/api/recognitions` serves up to 50 published, consented entries from the configured tenant. The home page shows their images in the carousel and a stationary **Name / Reward For** table immediately below. Without configured data, it retains the image-only demo artwork and does not invent employee names. If the database is unavailable, the editor reports an error; public view keeps the image-only fallback.
- This shared passcode is not per-user admin authentication or an audit trail. Before production with real employee names, replace it with role-checked staff identity and verify tenant/domain mapping, data consent, photo hosting and retention policies. In a multi-tenant deployment, resolve tenant by verified host rather than a single deployment-scoped slug.

## Tenant onboarding, branding and optional features

- During company onboarding, Safex Super Admin records the tenant company name, address, contact email and mobile number, plus its verified domain and sites. The migration stores the public-facing profile in `tenants` (`company_name`, `company_address`, `contact_email`, `contact_mobile_e164`); optional logo storage is represented by `logo_path`.
- The shared app header displays the tenant company name. Per the current UI request, there is no footer; address, email and mobile remain onboarding profile data and are not displayed in a footer. In this demo the contact fields are intentionally unset.
- The demo UI reads a typed `DEMO_TENANT` profile from `lib/demo-data.ts`. This is not connected to the database. Production must resolve the tenant from a verified host/domain on the server, load its profile, and pass only the approved public branding fields to the UI.
- `tenant_features` stores optional modules by tenant. Current demo flags cover voice reporting, training management, library, circulars, reward wall and push notifications. Employee lookup remains part of the shared reporting core; feature-gated modules use the same shared UI shell. Missing feature rows should be treated as disabled.
- The browser must not read or write `tenant_features` or change company branding. Safex Super Admin onboarding/feature changes belong behind authenticated server routes that verify active membership in `safex_platform_admins`; keep the service-role key server-only. The SQL migration revokes direct table grants from browser roles and includes RLS defense-in-depth policies. The Safex Super Admin management UI/API itself is not yet implemented.
- Keep tenant-specific differences in profile data and explicit feature flags, not separate vendor-specific UI forks. Preserve the core reporting/privacy workflows for every tenant.

## Production blockers before public launch

- Supply and approve the location-specific Life Saving Rules before publishing them; the current Life Saving Rule popup is a placeholder.
- The initial WBD master is in Supabase. Configure and verify the server-only directory environment in Vercel; 14 source rows still lack a unique, valid mobile for OTP (shared, malformed or missing), so phone-based sign-in must remain disabled for those records until corrected.
- Implement server-side tenant resolution from verified domain and a site directory scoped to that tenant.
- The employee search endpoint (`/api/employees`) uses the tenant/site-scoped Supabase source when configured, requires an active record at the selected site, applies a minimum query length, result limit and per-IP rate limit, and returns exactly Employee ID, name and designation. Same-origin validation is not identity verification; do not use this narrow lookup as authorization for protected employee data.
- Before enabling offline sync, apply and review `supabase/migrations/202610030002_offline_report_sync.sql` in staging; configure verified tenant domains, active site/employee records, the private storage bucket and server-only secrets. The route validates same-origin submissions, payloads, site/employee scope, private image type/size and database-backed request limits. Malware scanning, moderation and admin-reviewed attachment previews are still required before public production use.
- Implement OTP by matching Employee ID + submitted phone to the employee master, sending only to the registered phone, and then exposing only redacted summaries for the same vendor tenant. Configure an SMS provider and OTP limits/expiry.
- Implement Safety Officer sign-in, password reset, account lockout and email OTP with verified server-side authentication. The reference-inspired officer forms are preview-only; they do not send or store credentials.
- Add a site/vendor role-management process and audit logs. Test RLS in staging; service-role API code must repeat tenant/site/role checks because it bypasses RLS.
- Configure actual SOS numbers and backup contacts for each site; test every `tel:` link with the site owner.
- Configure push VAPID keys, a push sender, subscription storage, preference checks, unsubscribe/dead-endpoint cleanup, and generic lock-screen payloads. The UI permission request alone does not send push notifications.
- Confirm PWA icon/manifest, HTTPS, service-worker update strategy, browser/device install steps and privacy-safe offline policy. Private report data is not cached by the worker.
- Professionally review Hindi/Odia/Bengali/Punjabi/Marathi translations, accessibility, legal/privacy retention rules and incident-reporting workflow.
- Expand automated tests beyond the employee-master parser, and add monitoring, backups, secret rotation, deployment previews and production domain configuration.

## Safety/privacy defaults in this starter

- Home/report submission is public in the UI, but real report APIs are not connected yet.
- My Site Reports uses the active site context; it is not proof of identity.
- All Site Reports must verify the registered phone by OTP and stay within the same vendor tenant.
- Worker summaries mask reporter IDs. Full employee IDs and original attachments belong behind authorized access; reviewed previews only after moderation.
- Anonymous reports have no reporter Employee No. The server also rejects anonymous submissions outside Speak Up.
- Recognition names and reward reasons appear only in the table below the carousel when consented, published records exist. The `RecognitionGalleryItem` fields are optional to allow image-only demo artwork. No sample awardee names are displayed; obtain documented consent before displaying real employee names or photographs.
- Unsent reports and optional photos are held in the browser's IndexedDB outbox until the server confirms receipt; employee name/designation are not queued, only the selected Employee No. needed for server-side site validation. Avoid shared devices. The service worker never caches report/API responses.
- No real emergency phone numbers or employee roster data are committed to this repository; employee PII remains in the private Supabase project and is not returned by the public lookup.
